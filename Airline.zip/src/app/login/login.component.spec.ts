import { ComponentFixture, TestBed } from '@angular/core/testing';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { LoginComponent } from './login.component';
import { of } from 'rxjs';

describe('AuthComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    class StoreMock {
      select = jasmine.createSpy().and.returnValue(of({}));
      dispatch = jasmine.createSpy();
      pipe = jasmine.createSpy().and.returnValue(of('success'));
  }
    await TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [ LoginComponent ],
      providers: [
        {provide: Router, useValue: {}},
        {provide: Store, useClass: StoreMock}
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('test form group elements count', () => {
    const formElement = fixture.debugElement.nativeElement.querySelector('#loginForm');
    const inputElements = formElement.querySelectorAll('input');
    expect(inputElements.length).toEqual(3);
  });

  it('should create onInit', () => {
    expect(component.ngOnInit()).toBe();
  });

  it('should create onSubmit', () => {
    expect(component.onSubmit()).toBe();
  });

  it('check initial form valuess', () => {
    const loginForm = component.loginForm;
    const loginFormValues = {
      role: '',
      username: '',
      password: ''
    };
    expect(loginForm.value).toEqual(loginFormValues);
  });
});
