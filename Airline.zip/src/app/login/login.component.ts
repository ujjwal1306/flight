import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ChildActivationStart, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { loginStart } from '../core/store/actions/auth.actions';
import { getErrorMessage } from '../core/store/selectors/shared.selector';
import { AppState } from '../core/store/state/app.state';
import { imageData } from '../shared/image.mock';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  hide = true;
  loginForm: FormGroup;
  errorMessage: string;
 
  constructor(private route: Router, private store: Store<AppState>) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      role: new FormControl('', Validators.required),
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    });
  }
  onSubmit(): void{
    this.store.dispatch(loginStart(this.loginForm.value));
    this.store.select(getErrorMessage).subscribe((data) => this.errorMessage = data);
  }
}
