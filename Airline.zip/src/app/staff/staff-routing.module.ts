import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckInComponent } from './check-in/check-in.component';
import { InFlightComponent } from './in-flight/in-flight.component';
import { StaffComponent } from './staff.component';

const routes: Routes = [
  { path: '', component: StaffComponent },
  { path: 'check-in/:id', component: CheckInComponent},
  { path: 'in-flight/:id', component: InFlightComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StaffRoutingModule { }
