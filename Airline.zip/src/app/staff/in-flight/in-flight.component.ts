import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Flight } from 'src/app/core/models/Flight';
import { FlightService } from 'src/app/core/services/flight.service';

@Component({
  selector: 'app-in-flight',
  templateUrl: './in-flight.component.html'
})
export class InFlightComponent implements OnInit {

  flight: Flight = new Flight();
  id: number;

  constructor(private activeRoute: ActivatedRoute, private flightService: FlightService) { }

  ngOnInit(): void {
    this.activeRoute.params.subscribe(
      (params: Params) => this.id = params.id
    );
    this.flightService.getFlightById(this.id).subscribe((data) => this.flight = data);
  }

}
