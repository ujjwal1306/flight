import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StaffRoutingModule } from './staff-routing.module';
import { StaffComponent } from './staff.component';
import { SharedModule } from '../shared/shared.module';
import { CheckInComponent } from './check-in/check-in.component';
import { InFlightComponent } from './in-flight/in-flight.component';
import { MatTabsModule } from '@angular/material/tabs';


@NgModule({
  declarations: [
    StaffComponent,
    CheckInComponent,
    InFlightComponent
  ],
  imports: [
    CommonModule,
    StaffRoutingModule,
    SharedModule,
    MatTabsModule
  ]
})
export class StaffModule { }
