import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Flight } from '../core/models/Flight';
import { FlightService } from '../core/services/flight.service';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.scss']
})
export class StaffComponent implements OnInit {

  constructor(private flightService: FlightService, private route: Router) { }

  flightData: Flight[] = [];

  ngOnInit(): void {
    this.flightService.getFlightDetails().subscribe(
      data => this.flightData = data
    );
  }

  onCheckIn(id: number): void{
    this.route.navigate(['/staff/check-in/' + id]);
  }

  inFlight(id: number): void{
    this.route.navigate(['/staff/in-flight/' + id]);
  }

}
