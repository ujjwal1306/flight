import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Store } from '@ngrx/store';
import { Flight } from 'src/app/core/models/Flight';
import { FlightService } from 'src/app/core/services/flight.service';
import { loadFlight } from 'src/app/core/store/actions/flight.actions';
import { flightData } from 'src/app/core/store/selectors/flight.selector';

@Component({
  selector: 'app-check-in',
  templateUrl: './check-in.component.html'
})
export class CheckInComponent implements OnInit {

  constructor(private activeRoute: ActivatedRoute, private flightService: FlightService) { }

  flight: Flight = new Flight();
  id: number;

  ngOnInit(): void {
    this.activeRoute.params.subscribe(
      (params: Params) => this.id = params.id
    );
    this.flightService.getFlightById(this.id).subscribe((data) => this.flight = data);
  }

}
