import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import {ActivatedRoute, Router} from '@angular/router';
import {FormsModule} from '@angular/forms';

import { ManageAirlianceServicesComponent } from './manage-airliance-services.component';
import { of } from 'rxjs';

describe('ManageAncillarServicesComponent', () => {
  let component: ManageAirlianceServicesComponent;
  let fixture: ComponentFixture<ManageAirlianceServicesComponent>;
  const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

  beforeEach(async () => {
    class StoreMock {
      select = jasmine.createSpy().and.returnValue(of({}));
      dispatch = jasmine.createSpy();
      pipe = jasmine.createSpy().and.returnValue(of('success'));
  }
    await TestBed.configureTestingModule({
      declarations: [ ManageAirlianceServicesComponent ],
      providers: [
        { provide: Store, useClass: StoreMock },
        { provide: ActivatedRoute, useValue: {} },
        { provide: Router, useValue: routerSpy }
      ],
      imports: [
        FormsModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAirlianceServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create onInit', () => {
    expect(component.ngOnInit()).toBe();
  });

  it('should create onPanelOpen', () => {
    expect(component.panelData()).toBe();
  });

  it('should create onSubmit', () => {
    expect(component.onSubmit()).toBe();
  });

  it('should create onBack', () => {
    expect(component.onBack()).toBe();
  });
});
