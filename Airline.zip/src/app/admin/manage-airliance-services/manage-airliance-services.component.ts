import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Flight } from 'src/app/core/models/Flight';
import { loadFlight, updateFlight } from 'src/app/core/store/actions/flight.actions';
import { flightData } from 'src/app/core/store/selectors/flight.selector';
import { AppState } from 'src/app/core/store/state/app.state';

@Component({
  selector: 'app-manage-ancillary-services',
  templateUrl: './manage-airliance-services.component.html',
  styleUrls: ['./manage-airliance-services.component.scss']
})
export class ManageAirlianceServicesComponent implements OnInit {

  constructor(private store: Store<AppState>, private activeRoute: ActivatedRoute, private route: Router) { }

  id: number;
  flight: Flight = new Flight();
  finalData: Flight = new Flight();
  services: string[] = [];
  shop: string[] = [];
  service: string;
  shopItem: string;
  index = 1;
  update = -1;
  updateService = -1;
  updateForm: FormGroup;
  updateServiceForm: FormGroup;
  view = false;

  ngOnInit(){
    this.activeRoute.params.subscribe(
      (params: Params) => this.id = params.id
    );
    const id = this.id;
    this.store.dispatch(loadFlight({id}));
    this.store.select(flightData).subscribe((data) => this.flight = data);
  }

  panelData(){

    if (this.index === 1){
      for (const f of this.flight.ancillaryServices){
        this.services.push(f);
      }

      for (const s of this.flight.shopFlight){
        this.shop.push(s);
      }
    }

    this.index++;

  }

  onServiceSubmit(form: NgForm): void{
    this.services.push(this.service);
    form.reset();
  }

  onShopSubmit(form: NgForm): void{
    this.shop.push(this.shopItem);
    form.reset();
  }

  onServiceDelete(i: number): void{
    this.services.splice(i, 1);
  }

  onShopDelete(i: number): void{
    this.shop.splice(i, 1);
  }

  onUpdateCall(item: string): void{
    this.updateForm = new FormGroup({
      item: new FormControl(item, Validators.required)
    });
  }

  onServiceUpdateCall(item: string): void{
    this.updateServiceForm = new FormGroup({
      item: new FormControl(item, Validators.required)
    });
  }

  onShopUpdate(): void{
    this.shop[this.update] = this.updateForm.controls.item.value;
    this.update = -1;
  }

  onServiceUpdate(): void{
    this.services[this.updateService] = this.updateServiceForm.controls.item.value;
    this.updateService = -1;
  }

  onSubmit(): void{

    this.finalData.id = this.flight.id;
    this.finalData.flightId = this.flight.flightId;
    this.finalData.source = this.flight.source;
    this.finalData.destination = this.flight.destination;
    this.finalData.src = this.flight.src;
    this.finalData.dest = this.flight.dest;
    this.finalData.partner = this.flight.partner;
    this.finalData.routeId = this.flight.routeId;
    this.finalData.date = this.flight.date;
    this.finalData.time = this.flight.time;
    this.finalData.ancillaryServices = this.services;
    this.finalData.shopFlight = this.shop;

    const flight = this.finalData;
    this.store.dispatch(updateFlight({flight}));
    alert('Services Updated!!');
  }

  onBack(): void{
    this.route.navigate(['/admin']);
  }

}
