import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Store } from '@ngrx/store';
import { Flight } from 'src/app/core/models/Flight';
import { FlightService } from 'src/app/core/services/flight.service';

@Component({
  selector: 'app-manage-passenger',
  templateUrl: './manage-passenger.component.html'
})
export class ManagePassengerComponent implements OnInit {

  id: number;
  flight: Flight = new Flight();

  constructor(private activeRoute: ActivatedRoute, private store: Store, private flightService: FlightService) { }

  ngOnInit(){
    this.activeRoute.params.subscribe(
      (params: Params) => this.id = params.id
    );
    this.flightService.getFlightById(this.id).subscribe(
      data => this.flight = data
    );
  }

}
