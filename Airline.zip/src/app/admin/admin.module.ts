import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { SharedModule } from '../shared/shared.module';
import { CoreModule } from '../core/core.module';
import { ManagePassengerComponent } from './manage-passenger/manage-passenger.component';
import { ManageAirlianceServicesComponent } from './manage-airliance-services/manage-airliance-services.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AdminComponent,
    ManagePassengerComponent,
    ManageAirlianceServicesComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    SharedModule,
    CoreModule,
    MatExpansionModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class AdminModule { }
