import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AuthResponseData } from '../core/models/AuthResponseData';
import { FlightService } from '../core/services/flight.service';
import { isAuthenticated } from '../core/store/selectors/auth.selector';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {

  public flightData = [];
  res: AuthResponseData;

  constructor(private flightService: FlightService, private route: Router) { }

  ngOnInit(){
    this.flightService.getFlightDetails().subscribe(
      data => this.flightData = data
    );
  }

  managePassenger(id: number): void{
    this.route.navigate(['/admin/managePassenger/' + id]);
  }

  manageFlightServices(id: number): void{
    this.route.navigate(['/admin/manageService/' + id]);
  }

}
