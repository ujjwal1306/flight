import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FlightService } from '../core/services/flight.service';
import { AdminComponent } from './admin.component';
import { of } from 'rxjs';

describe('AdminComponent', () => {
  let component: AdminComponent;
  let fixture: ComponentFixture<AdminComponent>;
  let service: FlightService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminComponent],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [FlightService],
    }).compileComponents();
  });

  beforeEach(() => {
    service = TestBed.inject(FlightService);
    fixture = TestBed.createComponent(AdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create onInit', () => {
    expect(component.ngOnInit()).toBe();
  });

  it('should fetch the selected flight details', () => {
    component.ngOnInit();
    const result = [];
    spyOn(service, 'getFlightDetails').and.returnValue(of(result));
    expect((component.flightData = result));
  });
  it('should  display the details of passengers', () => {
    component.managePassenger(1);
  });
  it('should  manageFlightServices of selected flight', () => {
    component.manageFlightServices(1);
  });
});
