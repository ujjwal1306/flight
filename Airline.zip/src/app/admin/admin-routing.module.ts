import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { ManageAirlianceServicesComponent} from './manage-airliance-services/manage-airliance-services.component';
import { ManagePassengerComponent } from './manage-passenger/manage-passenger.component';

const routes: Routes = [
  { path: '', component: AdminComponent },
  { path: 'managePassenger/:id', component: ManagePassengerComponent},
  { path: 'manageService/:id', component: ManageAirlianceServicesComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
