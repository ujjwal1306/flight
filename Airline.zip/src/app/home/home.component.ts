import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { FlightService } from '../core/services/flight.service';
import { isAuthenticated } from '../core/store/selectors/auth.selector';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  

  constructor(private store: Store,public router:Router,public service:FlightService) { }
  username = '';
  ngOnInit(): void {
    if (this.login){
      this.store.select(isAuthenticated).subscribe((data) => this.username = data.role);
    }
   
  }

  login(){
    this.router.navigate(['/login']);
  }

}
