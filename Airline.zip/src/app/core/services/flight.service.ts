import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Flight } from '../models/Flight';

@Injectable({
  providedIn: 'root'
})
export class FlightService {

  constructor(private http: HttpClient) { 
   
  }

  url = 'http://localhost:3000/flights';

  getFlightDetails(): Observable<Flight[]>{
    return this.http.get<any>(this.url);
  }

  getFlightById(id: number): Observable<Flight>{
    return this.http.get<any>(this.url + '/' + id);
  }

  updateFlight(flight: Flight): Observable<Flight>{
    return this.http.put<Flight>(this.url + '/' + flight.id, flight);
  }
 

}
