import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Passenger } from '../models/Passenger';

@Injectable({
  providedIn: 'root'
})
export class PassengerService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:3000/passengers';

  addPassenger(passenger: Passenger): Observable<Passenger>{
    return this.http.post<Passenger>(this.url, passenger);
  }

  updatePassenger(id: number, passenger: Passenger): Observable<Passenger>{
    return this.http.put<Passenger>('http://localhost:3000/passengers/' + id, passenger);
  }

  getPassengers(id: string): Observable<Passenger[]>{
    return this.http.get<Passenger[]>(this.url).pipe(map((d) => d.filter((pass) => pass.flightId === id)));
  }

}
