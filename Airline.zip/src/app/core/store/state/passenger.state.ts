import { Passenger } from '../../models/Passenger';

export interface PassengerState {
    passengers: Passenger[] | null;
}

export const initialState: PassengerState = {
    passengers: null,
};
