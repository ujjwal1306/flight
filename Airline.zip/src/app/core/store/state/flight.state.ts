import { Flight } from '../../models/Flight';

export interface FlightState {
    flights: Flight[] | null;
    flight: Flight | null;
}

export const initialState: FlightState = {
    flights: null,
    flight: null,
};
