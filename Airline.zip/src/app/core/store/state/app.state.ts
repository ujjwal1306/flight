import { AuthReducer } from '../reducers/auth.reducer';
import { FlightReducer } from '../reducers/flight.reducer';
import { PassengerReducer } from '../reducers/passenger.reducer';
import { SharedReducer } from '../reducers/shared.reducer';
import { AUTH_STATE_NAME } from '../selectors/auth.selector';
import { FLIGHT_STATE_NAME } from '../selectors/flight.selector';
import { PASSENGER_STATE_NAME } from '../selectors/passengers.selector';
import { SHARED_STATE_NAME } from '../selectors/shared.selector';
import { AuthState } from './auth.state';
import { FlightState } from './flight.state';
import { PassengerState } from './passenger.state';
import { SharedState } from './shared.state';

export interface AppState{
    [SHARED_STATE_NAME]: SharedState;
    [AUTH_STATE_NAME]: AuthState;
    [PASSENGER_STATE_NAME]: PassengerState;
    [FLIGHT_STATE_NAME]: FlightState;
}

export const appReducer = {
    [SHARED_STATE_NAME]: SharedReducer,
    [AUTH_STATE_NAME]: AuthReducer,
    [PASSENGER_STATE_NAME]: PassengerReducer,
    [FLIGHT_STATE_NAME]: FlightReducer,
};
