import { AuthResponseData } from '../../models/AuthResponseData';

export interface AuthState{
    response: AuthResponseData | null;
}

export const initialState: AuthState = {
    response: null,
};
