export interface SharedState{
    errorMessage: string;
}

export const initialState: SharedState = {
    errorMessage: '',
};
