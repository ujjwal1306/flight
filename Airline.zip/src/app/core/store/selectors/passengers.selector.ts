import { createFeatureSelector, createSelector } from '@ngrx/store';
import { PassengerState } from '../state/passenger.state';

export const PASSENGER_STATE_NAME = 'passenger';

const getPassengerState = createFeatureSelector<PassengerState>(PASSENGER_STATE_NAME);

export const passengerData = createSelector(getPassengerState, (state) => {
    return state.passengers;
});
