import { createFeatureSelector, createSelector } from '@ngrx/store';
import { FlightState } from '../state/flight.state';

export const FLIGHT_STATE_NAME = 'flight';

const getFlightState = createFeatureSelector<FlightState>(FLIGHT_STATE_NAME);

export const flightData = createSelector(getFlightState, (state) => {
    return state.flight;
});
