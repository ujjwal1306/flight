import { createAction, props } from '@ngrx/store';
import { Flight } from '../../models/Flight';

export const LOAD_FLIGHT = '[flight page] load flight';
export const LOAD_FLIGHT_SUCCESS = '[flight page] load flight success';
export const UPDATE_FLIGHT = '[flight page] update flight';
export const UPDATE_FLIGHT_SUCCESS = '[flight page] update flight success';

export const loadFlight = createAction(LOAD_FLIGHT, props<{id: number}>());

export const loadFlightSuccess = createAction(LOAD_FLIGHT_SUCCESS, props<{flight: Flight}>());

export const updateFlight = createAction(UPDATE_FLIGHT, props<{flight: Flight}>());

export const updateFlightSuccess = createAction(UPDATE_FLIGHT_SUCCESS, props<{flight: Flight}>());
