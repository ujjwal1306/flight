import { createAction, props } from '@ngrx/store';
import { Passenger } from '../../models/Passenger';

export const LOAD_PASSENGERS = '[passenger page] load passengers';
export const LOAD_PASSENGERS_SUCCESS = '[passenger page] load passengers success';
export const ADD_PASSENGER = '[passenger page] add passenger';
export const ADD_PASSENGER_SUCCESS = '[passenger page] add passenger success';
export const UPDATE_PASSENGER = '[passenger page] update passenger';
export const UPDATE_PASSENGER_SUCCESS = '[passenger page] update passenger success';

export const loadPassengers = createAction(LOAD_PASSENGERS, props<{id: string}>());

export const loadPassengerSuccess = createAction(LOAD_PASSENGERS_SUCCESS,
     props<{passengers: Passenger[]}>());

export const addPassenger = createAction(ADD_PASSENGER, props<{passenger: Passenger}>());

export const addPassengerSuccess = createAction(ADD_PASSENGER_SUCCESS, props<{passenger: Passenger}>());

export const updatePassenger = createAction(UPDATE_PASSENGER, props<{passenger: Passenger}>());

export const updatePassengerSuccess = createAction(UPDATE_PASSENGER_SUCCESS, props<{passenger: Passenger}>());

