import { createReducer, on } from '@ngrx/store';
import { loadFlightSuccess, updateFlightSuccess } from '../actions/flight.actions';
import { FlightState, initialState } from '../state/flight.state';

const flightReducer = createReducer(initialState, on(
    loadFlightSuccess, (state, action) => {
        return {
            ...state,
            flight: action.flight,
        };
    }
),
on(updateFlightSuccess, (state, action) => {

    const flightData = action.flight.id === state.flight.id ? action.flight : state.flight;
    return {
        ...state,
        flight: flightData,
    };
})
);

export function FlightReducer(state, action): FlightState{
    return flightReducer(state, action);
}
