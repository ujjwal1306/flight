import { createReducer, on } from '@ngrx/store';
import { addPassengerSuccess, loadPassengerSuccess, updatePassengerSuccess } from '../actions/passenger.actions';
import { initialState, PassengerState } from '../state/passenger.state';

const passengerReducer = createReducer(initialState, on(
    loadPassengerSuccess, (state, action) => {
        return {
            ...state,
            passengers: action.passengers
        };
    }
),
on(addPassengerSuccess, (state, action) => {
    const passenger = {...action.passenger};
    return {
        ...state,
        passengers: [...state.passengers, passenger],
    };
}),
on(updatePassengerSuccess, (state, action) => {
    const updatedPassengers = state.passengers.map((passenger) => {
        return action.passenger.id === passenger.id ? action.passenger : passenger;
    });
    return {
        ...state,
        passengers: updatedPassengers,
    };
})
);

export function PassengerReducer(state, action): PassengerState{
    return passengerReducer(state, action);
}
