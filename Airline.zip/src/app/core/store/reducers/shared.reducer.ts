import { createReducer, on } from '@ngrx/store';
import { setErrorMessage } from '../actions/shared.actions';
import { initialState, SharedState } from '../state/shared.state';

const sharedReducer = createReducer(
    initialState,
    on(setErrorMessage, (state, action) => {
        return {
            ...state,
            errorMessage: action.message,
        };
    })
);

export function SharedReducer(state, action): SharedState {
    return sharedReducer(state, action);
}
