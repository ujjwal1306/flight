import { createReducer, on } from '@ngrx/store';
import { loginSuccess } from '../actions/auth.actions';
import { AuthState, initialState } from '../state/auth.state';

const authReducer = createReducer(initialState, on(
    loginSuccess, (state, action) => {
        const res = {...action.response};
        return {
            ...state,
            response: res
        };
    }
));

export function AuthReducer(state, action): AuthState{
    return authReducer(state, action);
}
