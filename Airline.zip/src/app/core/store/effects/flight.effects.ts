import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { map, mergeMap, switchMap } from 'rxjs/operators';
import { FlightService } from '../../services/flight.service';
import { loadFlight, loadFlightSuccess, updateFlight, updateFlightSuccess } from '../actions/flight.actions';

@Injectable()
export class FlightEffects {

    constructor(private actions$: Actions, private flightService: FlightService) {}

    loadFlight$ = createEffect(() => {
        return this.actions$.pipe(ofType(loadFlight),
        mergeMap((action) => {
            return this.flightService.getFlightById(action.id).pipe(
                map((flight) => {
                return loadFlightSuccess({flight});
            }));
        }));
    });

    updateFlight$ = createEffect(() => {
        return this.actions$.pipe(ofType(updateFlight),
        switchMap((action) => {
            return this.flightService.updateFlight(action.flight).pipe(
                map((flight) => {
                    return updateFlightSuccess({flight});
                })
            );
        })
        );
    });

}
