import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { map, mergeMap, switchMap } from 'rxjs/operators';
import { Passenger } from '../../models/Passenger';
import { PassengerService } from '../../services/passenger.service';
import { addPassenger, addPassengerSuccess, loadPassengers, loadPassengerSuccess, updatePassenger, updatePassengerSuccess } from '../actions/passenger.actions';

@Injectable()
export class PassengerEffects {

    constructor(private actions$: Actions, private passengerService: PassengerService) {}

    loadPassengers$ = createEffect(() => {
        return this.actions$.pipe(ofType(loadPassengers),
        mergeMap((action) => {
            return this.passengerService.getPassengers(action.id).pipe(
                map((passengers) => {
                return loadPassengerSuccess({passengers});
            }));
        }));
    });

    addPassenger$ = createEffect(() => {
        return this.actions$.pipe(ofType(addPassenger),
        mergeMap((action) => {
            return this.passengerService.addPassenger(action.passenger).pipe(
                map((passenger) => {
                    return addPassengerSuccess({passenger});
                })
            );
        })
        );
    });

    updatePassenger$ = createEffect(() => {
        return this.actions$.pipe(ofType(updatePassenger),
        switchMap((action) => {
            return this.passengerService.updatePassenger(action.passenger.id, action.passenger).pipe(
                map((passenger) => {
                    return updatePassengerSuccess({passenger});
                })
            );
        })
        );
    });

}
