import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { loginStart, loginSuccess } from '../actions/auth.actions';
import { catchError, exhaustMap, map } from 'rxjs/operators';
import { AuthService } from 'src/app/services/auth.service';
import { of } from 'rxjs';
import { setErrorMessage } from '../actions/shared.actions';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';

@Injectable()
export class AuthEffects{
    constructor(private action$: Actions,
                private authService: AuthService,
                private store: Store,
                private route: Router){}

    login$ = createEffect(() => {
        return this.action$.pipe(
            ofType(loginStart),
            exhaustMap((action) => {
                return this.authService.login(action)
                .pipe(map((data) => {
                    const response = data;
                    return loginSuccess({response});
                }),
                catchError((errResp) => {
                    return of(setErrorMessage({message: errResp.error}));
                })
                );
            })
        );
    });

    loginRedirect$ = createEffect(() => {
        return this.action$.pipe(ofType(loginSuccess), map((action) => {
            if (action.response.role === 'admin'){
                this.route.navigate(['/admin']);
            }
            else{
                this.route.navigate(['/staff']);
            }
        }));
    }, {dispatch: false});

}
