import { TestBed } from '@angular/core/testing';
import {Store} from '@ngrx/store';
import {Router} from '@angular/router';

import { AdminGuard } from './admin.guard';
import { of } from 'rxjs';

describe('AdminGuard', () => {
  let guard: AdminGuard;

  beforeEach(() => {
    class StoreMock {
      select = jasmine.createSpy().and.returnValue(of({}));
      dispatch = jasmine.createSpy();
      pipe = jasmine.createSpy().and.returnValue(of('success'));
  }
    TestBed.configureTestingModule({
      providers: [
        { provide: Store, useClass: StoreMock },
        { provide: Router, useValue: {} }
      ]
    });
    guard = TestBed.inject(AdminGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
