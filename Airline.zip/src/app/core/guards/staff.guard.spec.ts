import { TestBed } from '@angular/core/testing';
import {Store} from '@ngrx/store';
import {Router} from '@angular/router';

import { StaffGuard } from './staff.guard';
import { of } from 'rxjs';

describe('StaffGuard', () => {
  let guard: StaffGuard;

  beforeEach(() => {
    class StoreMock {
      select = jasmine.createSpy().and.returnValue(of({}));
      dispatch = jasmine.createSpy();
      pipe = jasmine.createSpy().and.returnValue(of('success'));
  }
    TestBed.configureTestingModule({
      providers: [
        { provide: Store, useClass: StoreMock },
        { provide: Router, useValue: {} }
      ]
    });
    guard = TestBed.inject(StaffGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
