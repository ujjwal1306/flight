export class Authenticate{
    role: string;
    username: string;
    password: string;
}
