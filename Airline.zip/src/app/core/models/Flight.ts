export class Flight{
    id: number;
    source: string;
    src: string;
    destination: string;
    dest: string;
    flightId: string;
    date: string;
    time: string;
    partner: string;
    routeId: string;
    ancillaryServices: string[];
    shopFlight: string[];
}
