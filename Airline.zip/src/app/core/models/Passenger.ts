export class Passenger{
    firstName: string;
    lastName: string;
    address: string;
    flightId: string;
    passport: string;
    birthdate: string;
    seatNumber: string;
    specialMeal: string;
    checkedIn: string;
    infants: string;
    wheelChair: string;
    ancillaryServices: string;
    servicesList: string[];
    shopFlight: string[];
    id: number;
}
