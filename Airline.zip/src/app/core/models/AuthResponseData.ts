export class AuthResponseData{
    id: number;
    role: string;
    username: string;
    token: string;
}
