import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Authenticate } from '../core/models/Authenticate';
import { AuthResponseData } from '../core/models/AuthResponseData';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  login(authenticate: Authenticate): Observable<AuthResponseData>{
    return this.http.post<AuthResponseData>('http://localhost:3000/login', authenticate);
  }
}
