import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { AuthService } from './auth.service';
import { Authenticate } from '../core/models/Authenticate';
import { AuthResponseData } from '../core/models/AuthResponseData';

describe('AuthService', () => {
  let service: AuthService;
  const authenticate: Authenticate = new Authenticate();
  authenticate.role = 'admin';
  authenticate.password = 'admin@123';
  authenticate.username = 'duncan';
  const authResponse: AuthResponseData = new AuthResponseData();
  authResponse.id = 1;
  authResponse.role = 'admin';
  authResponse.username = 'duncan';
  authResponse.token = 'admin-token';
  const auth: Authenticate = new Authenticate();
  auth.role = 'staff';
  auth.password = 'staff@123';
  auth.username = 'sarah';
  const authRes: AuthResponseData = new AuthResponseData();
  authRes.id = 2;
  authRes.role = 'staff';
  authRes.username = 'sarah';
  authRes.token = 'staff-token';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule
      ]
    });
    service = TestBed.inject(AuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should test login', () => {
    service.login(authenticate).subscribe(data => {
      expect(data).toBe(authResponse);
    });
  });

  it('should test login', () => {
    service.login(auth).subscribe(data => {
      expect(data).toBe(authRes);
    });
  });


});
