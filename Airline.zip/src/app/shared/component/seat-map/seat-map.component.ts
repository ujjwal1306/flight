import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Flight } from 'src/app/core/models/Flight';
import { Passenger } from 'src/app/core/models/Passenger';
import { loadPassengers } from 'src/app/core/store/actions/passenger.actions';
import { passengerData } from 'src/app/core/store/selectors/passengers.selector';
import { CheckInUndoComponent } from './check-in-undo/check-in-undo.component';
import { FlightServiceComponent } from './flight-service/flight-service.component';
import { seatMapConstants } from '../../seat.constants';

@Component({
  selector: 'app-seat-map',
  templateUrl: './seat-map.component.html',
  styleUrls: ['./seat-map.component.scss']
})
export class SeatMapComponent implements OnInit, OnChanges {

  @Input() status: boolean;
  @Input() flight: Flight;
  passengers: Passenger[] = [];
  passenger: Passenger = new Passenger();
  display = false;
  aComp = seatMapConstants.aComp;
  bComp = seatMapConstants.bComp;
  cComp = seatMapConstants.cComp;
  dComp = seatMapConstants.dComp;
  eComp = seatMapConstants.eComp;
  fComp = seatMapConstants.fComp;
  seatNumber = seatMapConstants.seatNumber;

  constructor(private route: Router, private matDialog: MatDialog, private store: Store) { }

  ngOnInit(): void {
  }

  ngOnChanges(): void{
    const id = this.flight.flightId;
    this.store.dispatch(loadPassengers({id}));
    this.store.select(passengerData).subscribe((data) => this.passengers = data);
  }

  onBack(): void{
    this.route.navigate(['/staff']);
  }

  onSeatClicked(seat: string): void{

      if (this.status){
        for (const p of this.passengers){
          if (p.seatNumber === seat && p.passport !== ''){
            this.matDialog.open(CheckInUndoComponent, {
              data: { ['passenger']: p }
            });
          }
          else if (p.seatNumber === seat && p.passport === ''){
            alert('No Passport Detail Provided By User!');
          }
        }
      }
      else{
        for (const p of this.passengers){
          if (p.seatNumber === seat && p.checkedIn === 'Yes' && p.passport !== ''){
            this.matDialog.open(FlightServiceComponent, {
              data: { ['passenger']: p, ['flight']: this.flight }
            });
          }
        }
      }

  }

  isSeatBooked(seat: string): boolean{
    for (const p of this.passengers){
      if (p.seatNumber === seat){
        this.passenger = p;
        return true;
      }
    }
    return false;
  }

  onDisplay(): void{
    this.display = true;
  }

}
