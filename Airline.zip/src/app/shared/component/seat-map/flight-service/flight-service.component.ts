import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Flight } from 'src/app/core/models/Flight';
import { Passenger } from 'src/app/core/models/Passenger';
import { updatePassenger } from 'src/app/core/store/actions/passenger.actions';

@Component({
  selector: 'app-flight-service',
  templateUrl: './flight-service.component.html',
  styleUrls: ['./flight-service.component.scss']
})
export class FlightServiceComponent implements OnInit {

  passenger: Passenger = new Passenger();
  finalData: Passenger = new Passenger();
  flight: Flight = new Flight();
  meal: string;
  optedMeal: string;
  shopFlight: string[] = [];
  services: string[] = [];
  ancillaryService: boolean;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<FlightServiceComponent>,
    private store: Store
  ) {
    this.passenger = data.passenger;
    this.flight = data.flight;

    for (const s of this.passenger.servicesList){
      this.services.push(s);
    }

    for (const f of this.passenger.shopFlight){
      this.shopFlight.push(f);
    }

    if (this.passenger.specialMeal === 'Yes'){
      this.optedMeal = 'Special';
      this.meal = 'Normal';
    }
    else{
      this.optedMeal = 'Normal';
      this.meal = 'Special';
    }

    if (this.passenger.ancillaryServices === 'Yes'){
      this.ancillaryService = true;
    }
    else{
      this.ancillaryService = false;
    }
   }

  ngOnInit(): void {
  }

  onMeal(): void{
    this.optedMeal = this.meal;
    this.meal = this.meal === 'Normal' ? 'Special' : 'Normal';
  }

  onShop(item: string): void{
    let res = true;
    for (const i of this.shopFlight){
      if (item === i){
        res = false;
      }
    }
    if (res){
      this.shopFlight.push(item);
    }
  }

  onService(item: string): void{
    let res = true;
    for (const i of this.services){
      if (item === i){
        res = false;
      }
    }
    if (res){
      this.services.push(item);
    }
  }

  onServiceDelete(index: number): void{
    this.services.splice(index, 1);
  }

  onShopDelete(index: number): void{
    this.shopFlight.splice(index, 1);
  }

  onSubmit(): void{

    if (this.optedMeal === 'Special'){
      this.finalData.specialMeal = 'Yes';
    }
    else{
      this.finalData.specialMeal = 'No';
    }

    this.finalData.servicesList = this.services;
    this.finalData.shopFlight = this.shopFlight;
    this.finalData.seatNumber = this.passenger.seatNumber;
    this.finalData.id = this.passenger.id;
    this.finalData.checkedIn = this.passenger.checkedIn;
    this.finalData.firstName = this.passenger.firstName;
    this.finalData.lastName = this.passenger.lastName;
    this.finalData.flightId = this.passenger.flightId;
    this.finalData.infants = this.passenger.infants;
    this.finalData.passport = this.passenger.passport;
    this.finalData.wheelChair = this.passenger.wheelChair;
    this.finalData.address = this.passenger.address;
    this.finalData.ancillaryServices = this.passenger.ancillaryServices;
    this.finalData.birthdate = this.passenger.birthdate;
    const passenger = this.finalData;
    this.store.dispatch(updatePassenger({passenger}));
    alert('Requests served!!');
    this.dialogRef.close();
  }

}
