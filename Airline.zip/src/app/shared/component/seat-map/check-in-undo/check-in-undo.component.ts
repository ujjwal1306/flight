import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Passenger } from 'src/app/core/models/Passenger';
import { updatePassenger } from 'src/app/core/store/actions/passenger.actions';

@Component({
  selector: 'app-check-in-undo',
  templateUrl: './check-in-undo.component.html'
})
export class CheckInUndoComponent implements OnInit {

  passenger: Passenger = new Passenger();
  finalData: Passenger = new Passenger();
  action: string;
  message: string;

  constructor(
  @Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef<CheckInUndoComponent>,
  private store: Store) {

    this.passenger = data.passenger;

    if (this.passenger.ancillaryServices === 'Yes'){
      this.message = 'Required';
    }
    else{
      this.message = 'Not Required';
    }

    if (this.passenger.checkedIn === 'Yes'){
      this.action = 'Undo Check-In';
    }
    else{
      this.action = 'Check-In';
    }

   }

  ngOnInit(): void {
  }

  onAction(): void{
      this.finalData.seatNumber = this.passenger.seatNumber;
      this.finalData.id = this.passenger.id;
      this.finalData.firstName = this.passenger.firstName;
      this.finalData.lastName = this.passenger.lastName;
      this.finalData.flightId = this.passenger.flightId;
      this.finalData.infants = this.passenger.infants;
      this.finalData.passport = this.passenger.passport;
      this.finalData.servicesList = this.passenger.servicesList;
      this.finalData.shopFlight = this.passenger.shopFlight;
      this.finalData.specialMeal = this.passenger.specialMeal;
      this.finalData.wheelChair = this.passenger.wheelChair;
      this.finalData.address = this.passenger.address;
      this.finalData.ancillaryServices = this.passenger.ancillaryServices;
      this.finalData.birthdate = this.passenger.birthdate;

      if (this.action === 'Undo Check-In'){
      this.finalData.checkedIn = 'No';
      const passenger = this.finalData;
      this.store.dispatch(updatePassenger({passenger}));
    }
    else{
      this.finalData.checkedIn = 'Yes';
      const passenger = this.finalData;
      this.store.dispatch(updatePassenger({passenger}));
    }

      this.dialogRef.close();
  }

}
