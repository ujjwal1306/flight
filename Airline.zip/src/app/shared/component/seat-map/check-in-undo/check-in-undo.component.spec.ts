import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {Store} from '@ngrx/store';
import { of } from 'rxjs';

import { CheckInUndoComponent } from './check-in-undo.component';

describe('CheckInUndoComponent', () => {
  let component: CheckInUndoComponent;
  let fixture: ComponentFixture<CheckInUndoComponent>;

  beforeEach(async () => {
    class StoreMock {
      select = jasmine.createSpy().and.returnValue(of({}));
      dispatch = jasmine.createSpy();
      pipe = jasmine.createSpy().and.returnValue(of('success'));
  }
    await TestBed.configureTestingModule({
      declarations: [ CheckInUndoComponent ],
      providers: [CheckInUndoComponent,
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: {} },
        { provide: Store, useClass: StoreMock }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckInUndoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create onInit', () => {
    expect(component.ngOnInit()).toBe();
  });

  it('should create onAction', () => {
    component.onAction();
  });
});
