import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Passenger } from 'src/app/core/models/Passenger';
import { loadPassengers, updatePassenger } from 'src/app/core/store/actions/passenger.actions';
import { passengerData } from 'src/app/core/store/selectors/passengers.selector';
import { AppState } from 'src/app/core/store/state/app.state';
import { seatMapConstants } from '../../seat.constants';

@Component({
  selector: 'app-seat-update',
  templateUrl: './seat-update.component.html'
})
export class SeatUpdateComponent implements OnInit {

  passenger: Passenger = new Passenger();
  finalData: Passenger = new Passenger();
  seatNumber: string;
  passengers: Passenger[] = [];
  flightId: string;
  seatBooked = true;
  message: string;
  availableSeats: string[] = [];
  aComp = seatMapConstants.aComp;
  bComp = seatMapConstants.bComp;
  cComp = seatMapConstants.cComp;
  dComp = seatMapConstants.dComp;
  eComp = seatMapConstants.eComp;
  fComp = seatMapConstants.fComp;
  seatUpdateForm: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<SeatUpdateComponent>,
    private store: Store<AppState>
  ) {
    this.passenger = data.passenger;
    this.seatNumber = this.passenger.seatNumber;
    this.flightId = this.data.flightId;
    if (this.passenger.ancillaryServices === 'Yes'){
      this.message = 'Required';
    }
    else{
      this.message = 'Not Required';
    }
  }

  ngOnInit(): void {
    this.seatUpdateForm = new FormGroup({
      seatNumber: new FormControl(this.seatNumber, Validators.required)
    }
  );
    const id = this.flightId;
    let flag = 0;
    this.store.dispatch(loadPassengers({id}));
    this.store.select(passengerData).subscribe((data) => {
      this.passengers = data;
      for (const a of this.aComp){
        for (const d of data){
          if (a === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(a);
        }
        flag = 0;
      }
      for (const b of this.bComp){
        for (const d of data){
          if (b === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(b);
        }
        flag = 0;
      }
      for (const c of this.cComp){
        for (const d of data){
          if (c === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(c);
        }
        flag = 0;
      }
      for (const d of this.dComp){
        for (const p of data){
          if (d === p.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(d);
        }
        flag = 0;
      }
      for (const e of this.eComp){
        for (const d of data){
          if (e === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(e);
        }
        flag = 0;
      }
      for (const f of this.fComp){
        for (const d of data){
          if (f === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(f);
        }
        flag = 0;
      }
    }
    );

  }

  onSubmit(): void{

    this.seatNumber = this.seatUpdateForm.controls.seatNumber.value;

    for (const p of this.passengers){
      if (this.seatNumber === p.seatNumber && this.passenger.id !== p.id){
        alert('Seat number is already booked!');
        this.seatBooked = false;
      }
    }

    if (this.seatBooked){
      this.finalData.seatNumber = this.seatNumber;
      this.finalData.id = this.passenger.id;
      this.finalData.checkedIn = this.passenger.checkedIn;
      this.finalData.firstName = this.passenger.firstName;
      this.finalData.lastName = this.passenger.lastName;
      this.finalData.flightId = this.passenger.flightId;
      this.finalData.infants = this.passenger.infants;
      this.finalData.passport = this.passenger.passport;
      this.finalData.servicesList = this.passenger.servicesList;
      this.finalData.shopFlight = this.passenger.shopFlight;
      this.finalData.specialMeal = this.passenger.specialMeal;
      this.finalData.wheelChair = this.passenger.wheelChair;
      this.finalData.address = this.passenger.address;
      this.finalData.ancillaryServices = this.passenger.ancillaryServices;
      this.finalData.birthdate = this.passenger.birthdate;
      const passenger = this.finalData;
      this.store.dispatch(updatePassenger({passenger}));
      alert('Seat Updated!!');
    }

    this.dialogRef.close();

  }

}
