import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Passenger } from 'src/app/core/models/Passenger';
import { addPassenger, loadPassengers, updatePassenger } from 'src/app/core/store/actions/passenger.actions';
import { passengerData } from 'src/app/core/store/selectors/passengers.selector';
import { seatMapConstants } from '../../seat.constants';

@Component({
  selector: 'app-add-update',
  templateUrl: './add-update.component.html',
  styleUrls: ['./add-update.component.scss']
})
export class AddUpdateComponent implements OnInit {

  passengerForm: FormGroup;
  passenger: Passenger = new Passenger();
  passengerData: Passenger[] = [];
  action: boolean;
  flightId: string;
  seat: string;
  availableSeats: string[] = [];
  aComp = seatMapConstants.aComp;
  bComp = seatMapConstants.bComp;
  cComp = seatMapConstants.cComp;
  dComp = seatMapConstants.dComp;
  eComp = seatMapConstants.eComp;
  fComp = seatMapConstants.fComp;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<AddUpdateComponent>,
    private store: Store
  ) {
    this.flightId = data.flightId;
    this.action = data.add;
    if (data.passenger){
      this.passenger = data.passenger;
      this.seat = data.passenger.seatNumber;
      this.passengerForm = new FormGroup({
        firstName: new FormControl(this.passenger.firstName, [Validators.required, Validators.pattern('[a-zA-Z]{5,10}')]),
        lastName: new FormControl(this.passenger.lastName, [Validators.required, Validators.pattern('[a-zA-Z]{5,10}')]),
        address: new FormControl(this.passenger.address, Validators.pattern('[a-zA-Z0-9,-/.: ]{15,40}')),
        flightId: new FormControl(this.passenger.flightId, Validators.required),
        passport: new FormControl(this.passenger.passport, Validators.pattern('[A-Z]{1}[1-9][0-9][0-9]{4}[8-9]')),
        birthdate: new FormControl(this.passenger.birthdate),
        seatNumber: new FormControl(this.seat, [
            Validators.required
        ]),
        specialMeal: new FormControl(this.passenger.specialMeal, Validators.required),
        checkedIn: new FormControl('No'),
        infants: new FormControl(this.passenger.infants, Validators.required),
        wheelChair: new FormControl(this.passenger.wheelChair, Validators.required),
        ancillaryServices: new FormControl(this.passenger.ancillaryServices, Validators.required),
      });
    }
    else{
      this.seat = '-- Seat Number --';
      this.passengerForm = new FormGroup({
        firstName: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z]{1,10}')]),
        lastName: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z]{1,10}')]),
        address: new FormControl('', Validators.pattern('[a-zA-Z0-9,-/.: ]{15,40}')),
        flightId: new FormControl(data.flightId),
        passport: new FormControl('', Validators.pattern('[A-Z]{1}[1-9][0-9][0-9]{4}[1-9]')),
        birthdate: new FormControl(''),
        seatNumber: new FormControl(this.seat, [
            Validators.required
        ]),
        specialMeal: new FormControl('', Validators.required),
        checkedIn: new FormControl('No'),
        infants: new FormControl('', Validators.required),
        wheelChair: new FormControl('', Validators.required),
        ancillaryServices: new FormControl('', Validators.required),
      });
    }
   }

  ngOnInit(): void {
    const id = this.flightId;
    let flag = 0;
    this.store.dispatch(loadPassengers({id}));
    this.store.select(passengerData).subscribe((data) => {
      this.passengerData = data;
      for (const a of this.aComp){
        for (const d of data){
          if (a === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(a);
        }
        flag = 0;
      }
      for (const b of this.bComp){
        for (const d of data){
          if (b === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(b);
        }
        flag = 0;
      }
      for (const c of this.cComp){
        for (const d of data){
          if (c === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(c);
        }
        flag = 0;
      }
      for (const d of this.dComp){
        for (const p of data){
          if (d === p.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(d);
        }
        flag = 0;
      }
      for (const e of this.eComp){
        for (const d of data){
          if (e === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(e);
        }
        flag = 0;
      }
      for (const f of this.fComp){
        for (const d of data){
          if (f === d.seatNumber){
            flag = 1;
          }
        }
        if (flag === 0){
          this.availableSeats.push(f);
        }
        flag = 0;
      }
    }
    );
  }

  onSubmit(): void{

    let seatBooked = true;
    const passenger: Passenger = this.passengerForm.value;
    passenger.servicesList = [];
    passenger.shopFlight = [];
    passenger.id = this.passenger.id;

    for (const p of this.passengerData){
      if (p.seatNumber === passenger.seatNumber && passenger.id !== p.id){
        alert('Seat number is already booked!');
        seatBooked = false;
      }
    }

    if (seatBooked){
      if (this.action){
        this.store.dispatch(addPassenger({passenger}));
        alert('Passenger Added!!');
      }
      else{
        this.store.dispatch(updatePassenger({passenger}));
        alert('Passenger Details Updated!!');
      }
    }

    this.dialogRef.close();
  }

}
