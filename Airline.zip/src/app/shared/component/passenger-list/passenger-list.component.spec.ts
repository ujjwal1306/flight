import { ComponentFixture, TestBed } from '@angular/core/testing';
import {MatDialog} from '@angular/material/dialog';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { PassengerListComponent } from './passenger-list.component';
import { of } from 'rxjs';

describe('PassengerListComponent', () => {
  let component: PassengerListComponent;
  let fixture: ComponentFixture<PassengerListComponent>;
  const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

  beforeEach(async () => {

    class StoreMock {
      select = jasmine.createSpy().and.returnValue(of({}));
      dispatch = jasmine.createSpy();
      pipe = jasmine.createSpy().and.returnValue(of('success'));
  }
    await TestBed.configureTestingModule({
      declarations: [ PassengerListComponent ],
      providers: [
        {provide: MatDialog, useValue: {}},
        {provide: Router, useValue: routerSpy},
        {provide: Store, useClass: StoreMock},
      ],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PassengerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create onInit', () => {
    expect(component.ngOnInit()).toBe();
  });

  it('should create onChanges', () => {
    expect(component.ngOnChanges()).toBe();
  });

  it('should create back', () => {
    expect(component.back()).toBe();
  });

  it('should create onDisplayAll', () => {
    expect(component.onDisplayAll()).toBe();
  });

  it('should create onFilterPassport', () => {
    expect(component.onFilterPassport()).toBe();
  });

  it('should create onFilterAddress', () => {
    expect(component.onFilterAddress()).toBe();
  });

  it('should create onFilterBirthDate', () => {
    expect(component.onFilterBirthDate()).toBe();
  });

  it('should create onCheckedIn', () => {
    expect(component.onCheckedIn()).toBe();
  });

  it('should create onNotCheckedIn', () => {
    expect(component.onNotCheckedIn()).toBe();
  });

  it('should create onWheelChair', () => {
    expect(component.onWheelChair()).toBe();
  });

  it('should create onInfants', () => {
    expect(component.onInfants()).toBe();
  });
});
