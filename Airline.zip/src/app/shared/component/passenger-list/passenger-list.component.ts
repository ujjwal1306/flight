import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Flight } from 'src/app/core/models/Flight';
import { Passenger } from 'src/app/core/models/Passenger';
import { PassengerService } from 'src/app/core/services/passenger.service';
import { loadPassengers } from 'src/app/core/store/actions/passenger.actions';
import { passengerData } from 'src/app/core/store/selectors/passengers.selector';
import { AddUpdateComponent } from '../add-update/add-update.component';
import { SeatUpdateComponent } from '../seat-update/seat-update.component';

@Component({
  selector: 'app-passenger-list',
  templateUrl: './passenger-list.component.html',
  styleUrls: ['./passenger-list.component.scss']
})
export class PassengerListComponent implements OnInit, OnChanges {

  @Input() type: boolean;
  @Input() flightData: Flight = new Flight();
  filteredPassengerData: Passenger[] = [];

  constructor(private dialog: MatDialog, private route: Router, private store: Store, private passServ: PassengerService) {
  }

  ngOnInit(): void {
  }

  ngOnChanges(): void{
    const id = this.flightData.flightId;
    this.store.dispatch(loadPassengers({id}));
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
  }

  updatePassenger(passenger, action: boolean): void{
    if (this.type){
      this.dialog.open(AddUpdateComponent, {
        data: { ['passenger']: passenger, ['flightId']: this.flightData.flightId , ['add']: action }
      });
    }
    else{
      this.dialog.open(SeatUpdateComponent, {
        data: { ['passenger']: passenger, ['flightId']: this.flightData.flightId }
      });
    }
  }

  back(): void{
    this.route.navigate(['/admin']);
  }

  backStaff(): void{
    this.route.navigate(['/staff']);
  }

  displayAllPassanger(): void{
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
  }

  onPassportFilter(): void{
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
    this.filteredPassengerData = this.filteredPassengerData.filter((data) => data.passport === '');
  }

  onAddressFilter(): void{
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
    this.filteredPassengerData = this.filteredPassengerData.filter((data) => data.address === '');
  }

  filterOnBirthDate(): void{
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
    this.filteredPassengerData = this.filteredPassengerData.filter((data) => data.birthdate === '');
  }

  onCheckedIn(): void{
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
    this.filteredPassengerData = this.filteredPassengerData.filter((data) => data.checkedIn === 'Yes');
  }

  onNotCheckedIn(): void{
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
    this.filteredPassengerData = this.filteredPassengerData.filter((data) => data.checkedIn === 'No');
  }

  onWheelChair(): void{
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
    this.filteredPassengerData = this.filteredPassengerData.filter((data) => data.wheelChair === 'Yes');
  }

  onInfants(): void{
    this.store.select(passengerData).subscribe((data) => this.filteredPassengerData = data);
    this.filteredPassengerData = this.filteredPassengerData.filter((data) => data.infants === 'Yes');
  }

}

