import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { AuthResponseData } from 'src/app/core/models/AuthResponseData';
import { loginSuccess } from 'src/app/core/store/actions/auth.actions';
import { isAuthenticated } from 'src/app/core/store/selectors/auth.selector';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(private store: Store, private route: Router) { }

  @Input() type = true;
  @Input() user: string;
  @Input() login = false;
  username = '';
  result: AuthResponseData = new AuthResponseData();

  ngOnInit(): void {

    if (this.login){
      this.store.select(isAuthenticated).subscribe((data) => this.username = data.role);
    }

  }

  onLogout(): void{
    this.result.role = '';
    this.result.username = '';
    this.store.dispatch(loginSuccess({response: this.result}));
    this.route.navigate(['']);
  }

}
