export const imageData={
    images: [
        {path:'/src/assets/corousel/courosel3.png'},
        {path:'/src/assets/corousel/courosel2.png'},
        {path:'/src/assets/corousel/courosel1.png'},
        {path:'/src/assets/corousel/courosel4.png'},
        {path:'/src/assets/corousel/courosel5.png'},
        {path:'/src/assets/corousel/courosel6.png'},

        
        // '/src/assets/corousel/courosel2.png',
        // '/src/assets/corousel/courosel4.png',
        // '/src/assets/corousel/courosel1.png',
        // '/src/assets/corousel/courosel6.png',
        // '/src/assets/corousel/courosel5.png',

      ],
}