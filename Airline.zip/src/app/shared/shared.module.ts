import { NgModule } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { PassengerListComponent } from './component/passenger-list/passenger-list.component';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { AddUpdateComponent } from './component/add-update/add-update.component';
import { SeatUpdateComponent } from './component/seat-update/seat-update.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '../core/core.module';
import { FormsModule } from '@angular/forms';
import { SeatMapComponent } from './component/seat-map/seat-map.component';
import { CheckInUndoComponent } from './component/seat-map/check-in-undo/check-in-undo.component';
import { FlightServiceComponent } from './component/seat-map/flight-service/flight-service.component';
import { MaterialModule } from './material/material.module';


@NgModule({
    declarations: [
        HeaderComponent,
        PassengerListComponent,
        AddUpdateComponent,
        SeatUpdateComponent,
        SeatMapComponent,
        CheckInUndoComponent,
        FlightServiceComponent,
    ],
    imports: [
        MatButtonModule,
        MatIconModule,
        MatDialogModule,
        CommonModule,
        ReactiveFormsModule,
        CoreModule,
        FormsModule,
        MaterialModule
    ],
    exports: [
        HeaderComponent,
        PassengerListComponent,
        SeatMapComponent,
        MaterialModule,
       
    ]
})
export class SharedModule{}
